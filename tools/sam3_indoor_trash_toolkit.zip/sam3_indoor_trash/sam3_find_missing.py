#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Find POSSIBLE missed litter annotations using SAM3 text prompts.

Run only AFTER refining existing labels, and manually review any proposals.
Never merges predicted detections into existing ground-truth labels.
"""
from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

import cv2
import numpy as np

from sam3_refine_yolo import (EXTS, Instance, draw_preview, load_polygons, mask_iou,
                              polygon_mask, read_image, save_labels, simplify_contour,
                              write_image)


def same_object(a: np.ndarray, b: np.ndarray) -> bool:
    ma, mb = a > 0, b > 0
    intersection = int(np.logical_and(ma, mb).sum())
    if not intersection:
        return False
    smaller = min(int(ma.sum()), int(mb.sum()))
    return mask_iou(a, b) > 0.25 or (intersection / smaller if smaller else 0) > 0.58


def main():
    p = argparse.ArgumentParser(description='Use SAM3 text prompts to flag likely missing YOLO segmentation instances.')
    p.add_argument('--dataset', type=Path, required=True)
    p.add_argument('--config', type=Path, required=True, help='JSON class ID -> list of English text prompts')
    p.add_argument('--out', type=Path, default=Path('sam3_missing_review'))
    p.add_argument('--model', default='sam3.pt')
    p.add_argument('--splits', nargs='+', default=['train'])
    p.add_argument('--limit', type=int, default=30, help='Number of images per split; 0=all')
    p.add_argument('--conf', type=float, default=0.40)
    p.add_argument('--device', default='0')
    p.add_argument('--preview-limit', type=int, default=100)
    a = p.parse_args()

    root, out = a.dataset.resolve(), a.out.resolve()
    if out == root or root in out.parents:
        raise SystemExit('Output must be separate from the input dataset.')
    config = json.loads(a.config.read_text(encoding='utf-8-sig'))
    if not isinstance(config, dict) or not config:
        raise SystemExit('Config must be {"0": ["plastic bottle", "plastic bag"], ...}')
    prompts = []
    for cls, descriptions in config.items():
        if not isinstance(descriptions, list) or not descriptions:
            raise SystemExit(f'Invalid description list for class {cls}')
        for desc in descriptions:
            if not isinstance(desc, str) or not desc.strip():
                raise SystemExit(f'Invalid prompt for class {cls}')
            prompts.append((int(cls), desc.strip()))

    try:
        from ultralytics.models.sam import SAM3SemanticPredictor
    except ImportError as e:
        raise SystemExit('Install a current ultralytics release with SAM3 support.') from e
    predictor = SAM3SemanticPredictor(overrides={
        'model': a.model, 'device': a.device, 'mode': 'predict',
        'task': 'segment', 'conf': a.conf, 'verbose': False,
    })
    rows = []
    previews = 0
    for split in a.splits:
        im_root = root / 'images' / split
        lab_root = root / 'labels' / split
        if not im_root.exists():
            print('Skip missing images:', im_root)
            continue
        images = sorted(x for x in im_root.rglob('*') if x.suffix.lower() in EXTS and x.is_file())
        if a.limit > 0:
            images = images[:a.limit]
        for index, img_path in enumerate(images, 1):
            rel = img_path.relative_to(im_root)
            label_file = lab_root / rel.with_suffix('.txt')
            candidates: list[Instance] = []
            try:
                image = read_image(img_path)
                h, w = image.shape[:2]
                old, warnings = load_polygons(label_file)
                old_masks = [polygon_mask(inst.xy, w, h) for inst in old]
                new_masks = []
                predictor.reset_image()
                predictor.set_image(image)
                for cls, text_prompt in prompts:
                    result_list = predictor(text=[text_prompt])
                    if not result_list or result_list[0].masks is None:
                        continue
                    r = result_list[0]
                    polygons = r.masks.xyn
                    confidences = (r.boxes.conf.cpu().numpy().tolist()
                                   if r.boxes is not None else [1.0] * len(polygons))
                    for j, poly in enumerate(polygons):
                        score = confidences[j] if j < len(confidences) else 1.0
                        if score < a.conf or len(poly) < 3:
                            continue
                        xy = simplify_contour(np.asarray(poly), w, h)
                        candidate_mask = polygon_mask(xy, w, h)
                        if int(candidate_mask.sum()) < 12:
                            continue
                        if any(same_object(candidate_mask, m) for m in old_masks + new_masks):
                            continue
                        candidates.append(Instance(cls, xy))
                        new_masks.append(candidate_mask)
                        rows.append({'split': split, 'image': rel.as_posix(),
                                     'class_id': cls, 'text_prompt': text_prompt,
                                     'confidence': round(float(score), 4),
                                     'status': 'REVIEW_POSSIBLE_MISSING'})
                if candidates:
                    save_labels(out / 'pending_labels' / split / rel.with_suffix('.txt'), candidates)
                    if previews < a.preview_limit:
                        # Left: pre-existing labels; right: ONLY the new suggestions.
                        preview = draw_preview(image, old, candidates,
                                               [(None, 'candidate') for _ in candidates], rel.name)
                        write_image(out / 'previews' / split / rel.with_suffix('.jpg'), preview)
                        previews += 1
                if warnings:
                    rows.append({'split': split, 'image': rel.as_posix(),
                                 'class_id': '', 'text_prompt': '', 'confidence': '',
                                 'status': 'CHECK_OLD_LABEL:' + ';'.join(warnings)})
            except Exception as e:
                print(f'[ERROR] {split}/{rel}: {e}')
                rows.append({'split': split, 'image': rel.as_posix(),
                             'class_id': '', 'text_prompt': '', 'confidence': '',
                             'status': 'ERROR:' + str(e)[:150]})
            if index % 10 == 0 or index == len(images):
                print(f'{split}: {index}/{len(images)}, suggestions: {sum(x["status"] == "REVIEW_POSSIBLE_MISSING" for x in rows)}')
    out.mkdir(parents=True, exist_ok=True)
    csv_path = out / 'missing_suggestions.csv'
    with csv_path.open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=['split', 'image', 'class_id', 'text_prompt', 'confidence', 'status'])
        writer.writeheader()
        writer.writerows(rows)
    print(f'Wrote {csv_path} and optional previews / pending_labels.')
    print('IMPORTANT: pending_labels are NOT verified truth. Check before merging into YOLO training labels.')


if __name__ == '__main__':
    main()
