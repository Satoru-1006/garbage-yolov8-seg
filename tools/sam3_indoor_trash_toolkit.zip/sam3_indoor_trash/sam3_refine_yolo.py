#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""SAM 3-assisted review of an EXISTING YOLOv8 instance-segmentation dataset.

Creates a SEPARATE candidate dataset, visual comparisons and a CSV review queue.
Original images and annotations are never overwritten. SAM 3 does not assign
semantic classes: each proposed outline inherits its original YOLO class ID.

See README.md for installation and example commands.
"""

from __future__ import annotations

import argparse
import csv
import os
import random
import shutil
from pathlib import Path
from typing import NamedTuple

import cv2
import numpy as np
import yaml

EXTS = {'.jpg', '.jpeg', '.png', '.bmp', '.webp', '.tif', '.tiff'}


class Instance(NamedTuple):
    cls: int
    xy: np.ndarray  # normalized (N, 2)


def read_image(path: Path) -> np.ndarray:
    # Supports non-ASCII file paths on Linux and Windows.
    buffer = np.fromfile(str(path), dtype=np.uint8)
    image = cv2.imdecode(buffer, cv2.IMREAD_COLOR)
    if image is None:
        raise ValueError(f'Cannot decode image: {path}')
    return image


def write_image(path: Path, image: np.ndarray) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    ext = path.suffix.lower() or '.jpg'
    ok, encoded = cv2.imencode(ext, image)
    if not ok:
        raise ValueError(f'Cannot encode image: {path}')
    encoded.tofile(str(path))


def load_polygons(path: Path) -> tuple[list[Instance], list[str]]:
    items: list[Instance] = []
    warnings: list[str] = []
    if not path.exists():
        return items, ['label_file_missing']
    for lineno, raw in enumerate(path.read_text(encoding='utf-8-sig').splitlines(), 1):
        parts = raw.strip().split()
        if not parts:
            continue
        try:
            cls = int(parts[0])
            coords = np.array([float(v) for v in parts[1:]], dtype=np.float32)
            if cls < 0 or len(coords) < 6 or len(coords) % 2 or not np.isfinite(coords).all():
                raise ValueError('invalid polygon')
            poly = coords.reshape(-1, 2)
            if (poly < -0.001).any() or (poly > 1.001).any():
                raise ValueError('coordinates outside [0,1]')
            items.append(Instance(cls, np.clip(poly, 0, 1)))
        except (ValueError, TypeError) as exc:
            warnings.append(f'invalid_line_{lineno}:{exc}')
    return items, warnings


def normalized_to_pixels(poly: np.ndarray, w: int, h: int) -> np.ndarray:
    return np.rint(poly * np.array([w - 1, h - 1])).astype(np.int32)


def polygon_mask(poly: np.ndarray, w: int, h: int) -> np.ndarray:
    mask = np.zeros((h, w), dtype=np.uint8)
    if len(poly) >= 3:
        cv2.fillPoly(mask, [normalized_to_pixels(poly, w, h)], 1)
    return mask


def mask_iou(a: np.ndarray, b: np.ndarray) -> float:
    inter = np.logical_and(a > 0, b > 0).sum()
    union = np.logical_or(a > 0, b > 0).sum()
    return float(inter / union) if union else 0.0


def bbox_from_polygon(poly: np.ndarray, w: int, h: int, pad: float) -> list[float]:
    pts = normalized_to_pixels(poly, w, h).astype(np.float32)
    x1, y1 = pts.min(axis=0)
    x2, y2 = pts.max(axis=0)
    width, height = max(1, x2 - x1), max(1, y2 - y1)
    return [float(max(0, x1 - width * pad)), float(max(0, y1 - height * pad)),
            float(min(w - 1, x2 + width * pad)), float(min(h - 1, y2 + height * pad))]


def simplify_contour(poly: np.ndarray, w: int, h: int) -> np.ndarray:
    """Reduce polygon vertex count, while preserving a usable YOLO contour."""
    pts = normalized_to_pixels(poly, w, h).astype(np.float32)
    if len(pts) < 3:
        return poly
    closed = pts.reshape(-1, 1, 2)
    perimeter = cv2.arcLength(closed, True)
    for fraction in (0.0015, 0.003, 0.006, 0.012):
        approx = cv2.approxPolyDP(closed, max(0.5, perimeter * fraction), True).reshape(-1, 2)
        if 3 <= len(approx) <= 250:
            return np.clip(approx / np.array([max(w - 1, 1), max(h - 1, 1)]), 0, 1)
    return poly


def save_labels(path: Path, labels: list[Instance]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = []
    for cls, xy in labels:
        if len(xy) >= 3:
            lines.append(f'{cls} ' + ' '.join(f'{v:.6f}' for v in xy.reshape(-1)))
    path.write_text(('\n'.join(lines) + '\n') if lines else '', encoding='utf-8')


def draw_preview(original: np.ndarray, old: list[Instance], new: list[Instance],
                 scores: list[tuple[float | None, str]], label: str) -> np.ndarray:
    h, w = original.shape[:2]
    panels = []
    for title, instances, color in [('Old labels', old, (0, 50, 240)),
                                    ('SAM3 candidates', new, (40, 210, 40))]:
        panel = original.copy()
        overlay = panel.copy()
        for inst in instances:
            pts = normalized_to_pixels(inst.xy, w, h)
            cv2.fillPoly(overlay, [pts], color)
            cv2.polylines(panel, [pts], True, color, 2)
        panel = cv2.addWeighted(overlay, .22, panel, .78, 0)
        # Draw crisp contours over translucent masks.
        for inst in instances:
            cv2.polylines(panel, [normalized_to_pixels(inst.xy, w, h)], True, color, 2)
        cv2.rectangle(panel, (0, 0), (min(w - 1, 350), 35), (25, 25, 25), -1)
        cv2.putText(panel, title, (8, 25), cv2.FONT_HERSHEY_SIMPLEX, .68,
                    (255, 255, 255), 2, cv2.LINE_AA)
        panels.append(panel)
    composite = np.concatenate(panels, axis=1)
    stats = ', '.join('failed' if score is None else f'{score:.2f}' for score, _ in scores)
    footer = np.full((42, composite.shape[1], 3), 248, dtype=np.uint8)
    cv2.putText(footer, f'{label} | instance mask IoU: {stats[:110]}', (8, 28),
                cv2.FONT_HERSHEY_SIMPLEX, .53, (30, 30, 30), 1, cv2.LINE_AA)
    return np.concatenate([composite, footer], axis=0)


def source_dataset_names(root: Path, data_yaml: str | None, found_ids: set[int]) -> dict[int, str]:
    data_path = Path(data_yaml) if data_yaml else root / 'data.yaml'
    if data_path.exists():
        data = yaml.safe_load(data_path.read_text(encoding='utf-8-sig')) or {}
        names = data.get('names', {})
        if isinstance(names, list):
            names = {i: str(name) for i, name in enumerate(names)}
        elif isinstance(names, dict):
            names = {int(k): str(v) for k, v in names.items()}
        else:
            names = {}
    else:
        names = {}
    for i in found_ids:
        names.setdefault(i, f'class_{i}')
    if not names:
        names = {0: 'trash'}
    return dict(sorted(names.items()))


def link_or_copy(src: Path, dest: Path) -> None:
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.exists():
        return
    try:
        os.link(src, dest)
    except OSError:
        shutil.copy2(src, dest)


def main() -> None:
    parser = argparse.ArgumentParser(description='Use SAM3 to propose corrected YOLO segmentation labels.')
    parser.add_argument('--dataset', type=Path, required=True, help='Root containing images/train and labels/train')
    parser.add_argument('--out', type=Path, default=Path('sam3_output'))
    parser.add_argument('--model', default='sam3.pt', help='SAM3 model weight name or .pt path')
    parser.add_argument('--data-yaml', help='Optional YAML containing your ORIGINAL class names')
    parser.add_argument('--splits', nargs='+', default=['train'], help='Only run on training split by default')
    parser.add_argument('--limit', type=int, default=50, help='Number of images per split; 0 means all')
    parser.add_argument('--seed', type=int, default=42, help='Seed for representative random subset')
    parser.add_argument('--pad', type=float, default=0.06, help='Relative padding around existing bounding box')
    parser.add_argument('--flag-iou', type=float, default=0.75, help='Flag if old-vs-SAM mask IoU below this')
    parser.add_argument('--preview-limit', type=int, default=120, help='Preview count; prioritized to flagged files')
    parser.add_argument('--device', default='0', help='CUDA device ID, e.g. 0')
    args = parser.parse_args()
    root = args.dataset.resolve()
    out = args.out.resolve()
    if out == root or root in out.parents:
        raise SystemExit('Output directory cannot be the original dataset or nested under it. Use a separate directory.')
    if not (0 <= args.pad <= 0.5 and 0 <= args.flag_iou <= 1):
        raise SystemExit('--pad must be 0-0.5, --flag-iou must be 0-1')

    try:
        from ultralytics.models.sam.predict import SAM3Predictor
    except ImportError as exc:
        raise SystemExit('Please install the latest ultralytics with SAM3 support.') from exc

    predictor = SAM3Predictor(overrides={
        'model': args.model, 'task': 'segment', 'mode': 'predict',
        'device': args.device, 'conf': 0.1, 'verbose': False, 'imgsz': 1008,
    })
    # Start with the pre-existing labels; keep a separate candidate dataset.
    summary_rows = []
    all_ids: set[int] = set()
    preview_count = 0
    for split in args.splits:
        src_imgs = root / 'images' / split
        src_lbls = root / 'labels' / split
        if not src_imgs.exists():
            print(f'[SKIP] Missing image directory: {src_imgs}')
            continue
        paths = sorted((p for p in src_imgs.rglob('*') if p.is_file() and p.suffix.lower() in EXTS))
        if args.limit > 0:
            paths = sorted(random.Random(args.seed).sample(paths, min(len(paths), args.limit)))
        print(f'Processing {split}: {len(paths)} images')
        for idx, image_path in enumerate(paths, 1):
            rel = image_path.relative_to(src_imgs)
            old_label_path = src_lbls / rel.with_suffix('.txt')
            new_label_path = out / 'dataset' / 'labels' / split / rel.with_suffix('.txt')
            try:
                image = read_image(image_path)
                h, w = image.shape[:2]
                old, warnings = load_polygons(old_label_path)
                all_ids.update(x.cls for x in old)
                revised: list[Instance] = []
                comparisons: list[tuple[float | None, str]] = []
                if old:
                    predictor.reset_image()
                    predictor.set_image(image)
                for original in old:
                    bbox = bbox_from_polygon(original.xy, w, h, args.pad)
                    # Query each instance separately to preserve its original class ID.
                    try:
                        results = predictor(bboxes=[bbox])
                        if not results or results[0].masks is None:
                            raise ValueError('no SAM3 mask')
                        proposals = results[0].masks.xyn
                        if not proposals:
                            raise ValueError('no SAM3 contour')
                        old_mask = polygon_mask(original.xy, w, h)
                        scored = []
                        for proposal in proposals:
                            if len(proposal) >= 3:
                                candidate = simplify_contour(np.array(proposal), w, h)
                                quality = mask_iou(old_mask, polygon_mask(candidate, w, h))
                                scored.append((quality, candidate))
                        if not scored:
                            raise ValueError('invalid SAM3 contours')
                        iou, poly = max(scored, key=lambda item: item[0])
                        revised.append(Instance(original.cls, poly))
                        comparisons.append((iou, 'review' if iou < args.flag_iou else 'check_sample'))
                    except (RuntimeError, ValueError, AttributeError, IndexError) as exc:
                        revised.append(original)  # never delete a target on inference failure
                        comparisons.append((None, f'failed:{str(exc)[:100]}'))
                    finally:
                        # Do not clear cached image features between boxes.
                        pass
                save_labels(new_label_path, revised)
                link_or_copy(image_path, out / 'dataset' / 'images' / split / rel)
                scores = [v for v, _ in comparisons if v is not None]
                flagged = bool(warnings) or not old or any(v is None or v < args.flag_iou for v, _ in comparisons)
                status = 'REVIEW_EMPTY' if not old else ('REVIEW' if flagged else 'SAMPLE_CHECK')
                record = {
                    'split': split, 'image': rel.as_posix(), 'status': status,
                    'instances': len(old), 'mean_mask_iou': f'{np.mean(scores):.4f}' if scores else '',
                    'min_mask_iou': f'{min(scores):.4f}' if scores else '',
                    'original_label': str(old_label_path), 'candidate_label': str(new_label_path),
                    'notes': ';'.join(warnings + [note for score, note in comparisons if score is None]),
                }
                summary_rows.append(record)
                if (flagged or preview_count < min(10, args.preview_limit)) and preview_count < args.preview_limit:
                    preview = draw_preview(image, old, revised, comparisons, rel.name)
                    write_image(out / 'previews' / split / rel.with_suffix('.jpg'), preview)
                    preview_count += 1
                if idx % 10 == 0 or idx == len(paths):
                    print(f'  {idx}/{len(paths)} | flagged so far: '
                          f'{sum(r["status"] == "REVIEW" for r in summary_rows)}')
            except Exception as exc:
                # Preserve the exact old label on errors whenever possible.
                print(f'[ERROR] {split}/{rel}: {exc}')
                old, _ = load_polygons(old_label_path)
                save_labels(new_label_path, old)
                link_or_copy(image_path, out / 'dataset' / 'images' / split / rel)
                summary_rows.append({
                    'split': split, 'image': rel.as_posix(), 'status': 'ERROR',
                    'instances': len(old), 'mean_mask_iou': '', 'min_mask_iou': '',
                    'original_label': str(old_label_path), 'candidate_label': str(new_label_path),
                    'notes': str(exc),
                })
    out.mkdir(parents=True, exist_ok=True)
    csv_path = out / 'review_queue.csv'
    fields = ['split', 'image', 'status', 'instances', 'mean_mask_iou', 'min_mask_iou',
              'original_label', 'candidate_label', 'notes']
    summary_rows.sort(key=lambda x: (0 if x['status'] in {'REVIEW', 'REVIEW_EMPTY', 'ERROR'} else 1,
                                     float(x['min_mask_iou']) if x['min_mask_iou'] else 2.0))
    with csv_path.open('w', newline='', encoding='utf-8-sig') as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(summary_rows)
    if summary_rows:
        names = source_dataset_names(root, args.data_yaml, all_ids)
        new_yaml = {'path': str(out / 'dataset'),
                    **{s: 'images/' + s for s in args.splits if (out / 'dataset/images' / s).exists()},
                    'names': names}
        (out / 'dataset' / 'data.yaml').write_text(yaml.safe_dump(new_yaml, allow_unicode=True,
                                                     sort_keys=False), encoding='utf-8')
    print(f'\nFinished. Review: {csv_path}')
    print(f'Candidates: {out / "dataset"}')
    print(f'Previews: {out / "previews"}')
    print('CAUTION: Results are unverified suggestions. Do not train on them until reviewed.')


if __name__ == '__main__':
    main()
