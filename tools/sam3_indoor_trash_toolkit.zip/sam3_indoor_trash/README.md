# SAM 3 辅助修复 YOLOv8-Seg 室内垃圾标注

用于已存在 `images/{train,val}`、`labels/{train,val}` 的 YOLO 实例分割数据集。利用每个原始分割多边形导出的边界框作为 **SAM 3 几何提示**，生成更精细的候选多边形。保留原来的类别编号，输出独立的数据目录与人工复核清单。

## 1. 运行环境

建议在 NVIDIA GPU 的 Linux 主机上安装 PyTorch（请按自己的 NVIDIA 驱动/CUDA 环境参考 [PyTorch 官方说明](https://pytorch.org/get-started/locally/)），然后：

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
pip install -U ultralytics opencv-python-headless numpy pyyaml
```

PyTorch 应确保 CUDA 版本可用：

```bash
python -c "import torch; print(torch.__version__, torch.cuda.is_available())"
```

模型文件可通过 Ultralytics 支持的 `sam3.pt` 自动下载机制获取；根据网络、版本和模型授权条件，可能需要事先下载权重，再通过 `--model /绝对路径/sam3.pt` 指向模型。

## 2. 输入数据布局

```text
my_dataset/
  data.yaml
  images/
    train/
      0001.jpg
  labels/
    train/
      0001.txt
```

`0001.txt` 每行是 `类别编号 x1 y1 x2 y2 ...`，坐标 0~1，是 YOLO **实例分割** 多边形，而非检测框 `类别 x中心 y中心 宽 高`。

## 3. 先测试 50 张

```bash
python sam3_refine_yolo.py \
  --dataset /path/to/my_dataset \
  --out /path/to/sam3_review_50 \
  --splits train \
  --limit 50 \
  --model sam3.pt \
  --device 0
```

全部训练集：

```bash
python sam3_refine_yolo.py \
  --dataset /path/to/my_dataset \
  --out /path/to/sam3_review_full \
  --splits train \
  --limit 0 \
  --model sam3.pt
```

默认不处理验证集与测试集。**建议原始 val/test 保留为人工核实的可靠评估集**，不要把模型的自动候选标注直接当成测试真值。不要对旧数据集使用同一个输出目录。

## 4. 输出

```text
sam3_review_50/
  review_queue.csv      # 按可疑程度排序。低 IoU=差异大，不等于 SAM 一定正确
  previews/train/       # 原标注 vs SAM3 候选的左右对照
  dataset/
    data.yaml
    images/train/       # 尽可能使用硬链接，不行就复制；不修改原图
    labels/train/       # 新候选标签，保持原类别
```

**注意：这个脚本只修复已有实例的轮廓**。它无法可靠判断标签是否错类、是否应当作为垃圾，也不能发现所有漏标目标。漏标需要额外的 SAM 3 文本发现阶段或人工检查。对轻微粗糙的旧标注，SAM 也可能反而分错；请人工审核低 IoU 图像和随机抽样的高 IoU 图像。若旧标签严重错位，边界框本身不准，SAM 也未必能修复。

## 5. 和 YOLOv8-Seg 训练的连接

确认标签质量后才考虑使用 `sam3_review_full/dataset/data.yaml` 训练；如果其中只有 `train` split，请保留一个独立、人工校验且无泄漏的验证集，不要仅用生成的临时训练集声称 mAP 有提升。

## 6. 软件/许可

SAM3、Ultralytics 以及数据集来源均需要分别遵守各自许可条款；尤其当模型将用于商业清洁机器人时，请先进行许可合规审查。

官方接口依据：[SAM 3 文档](https://docs.ultralytics.com/models/sam-3)、[SAM3Predictor API](https://docs.ultralytics.com/reference/models/sam/predict)。

## 7. 第二步：SAM 3 文本提示寻找疑似漏标

在**候选轮廓已经核验并确认类别映射正确**后，可另外运行文本提示脚本：

```bash
python sam3_find_missing.py \
  --dataset /path/to/reviewed_dataset \
  --config prompts.single_class.example.json \
  --out /path/to/sam3_missing_review \
  --limit 30
```

如果多类别，用 `prompts.multi_class.example.json` **先修改其中的类别编号，必须与你自己的 data.yaml 完全一致**。英文提示词也可以改成与你现场垃圾更接近的描述。运行全部训练图像时使用 `--limit 0`。

输出为 `missing_suggestions.csv`、`previews/` 和 `pending_labels/`，**绝对不会自动把疑似漏标候选并入原始标签**。候选中的误检可能很多，例如塑料盒与非垃圾用品混淆；需要人确认是否属于需要清理的垃圾。此流程比单独基于旧标签框修边更可能发现漏标，但是也无法保证零漏检。
